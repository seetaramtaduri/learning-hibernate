package com.bullraider.manytoone;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.bullraider.manytoone.util.*;
public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Department dept1=new Department(10);
			Employee employee1=new Employee("Pradeep","SALESMAN",12000,10);
			Department dept2=new Department(20);
			Employee employee2=new Employee("Raja","MGR",124000,20);
			session.save(dept1);
			session.save(employee1);
			session.save(dept2);
			session.save(employee2);
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}


}


