package com.bullraider.manytoone;
public class Department {
	
	private long id;
	private int deptno;
	public Department(int id) {
		this.id=id;
		
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	}
