package com.bullraider.nsq;


import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
public class EmployeeDao {

	public static void main(String[] args) {
		EmployeeDao dao=new EmployeeDao();
		dao.saveEmployee();
		dao.retriveEmployee();

	}
	public void saveEmployee()

	{

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		Long empId = null;
		try {
			transaction = session.beginTransaction();
			Employee emp1=new Employee("Alok","SALESMAN",2000,10);
			Employee emp2=new Employee("Bhibhu","MGR",2000,20);
			Employee emp3=new Employee("Ameet","SALESMAN",18000,10);
			Employee emp4=new Employee("Prasdeep","CLERK",10000,10);
			session.save(emp1);
			session.save(emp2);
			session.save(emp3);
			session.save(emp4);
			EmployeeDao dao=new EmployeeDao();
			dao.retriveEmployee();
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}


	}
	public void retriveEmployee() 

	{ 

		Session session = HibernateUtil.getSessionFactory().openSession(); 
		Transaction transaction = null; 
		try { 
			transaction = session.beginTransaction(); 
			System.out.println("HI");
			List emp= session.getNamedQuery("selectEmp").list(); 
			System.out.println("Size is"+" "+emp.size());
			System.out.println("HI");
			for (Iterator iterator = emp.iterator(); iterator.hasNext();) 
			{ 
				Employee employee1 = (Employee) iterator.next(); 
				System.out.println(employee1.getEname()+"  "+
						employee1.getSal()); 
			}           
			transaction.commit(); 

		} catch (HibernateException e) { 

			transaction.rollback(); 

			e.printStackTrace(); 

		} finally { 

			session.close(); 
		} 
	}


}


