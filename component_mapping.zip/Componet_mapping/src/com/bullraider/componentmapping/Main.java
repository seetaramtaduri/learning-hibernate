package com.bullraider.componentmapping;


import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Expression;

import com.bullraider.componentmapping.util.HibernateUtil;


public class Main{

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		Long empId = null;
		try {
			transaction = session.beginTransaction();
			
			Address address1=new Address("Bangalore","Karnattaka","a001","560044");
			Employee emp1=new Employee("Prakash","SALESMAN",12000,10,address1);
			Address address2=new Address("Bangalore","Karnattaka","a001","560044");
			Employee emp2=new Employee("Pradeep","SALESMAN",12000,10,address2);
			Address address3=new Address("Bangalore","Karnattaka","a001","560044");
			Employee emp3=new Employee("Bijay","SALESMAN",12000,10,address3);
			Address address4=new Address("Bangalore","Karnattaka","a001","560044");
			Employee emp4=new Employee("Arpita","SALESMAN",12000,10,address4);
			session.save(emp1);
			session.save(emp2);
			session.save(emp3);
			session.save(emp4);
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
			Main m=new Main();
			m.retriveEmployee();
			
			
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}}

	
	public void retriveEmployee() 

	{ 
		
		Session session = HibernateUtil.getSessionFactory().openSession(); 
		Transaction transaction = null; 
		try { 
			transaction = session.beginTransaction(); 
			List employee=session.createQuery("from Employee").list();
			for (Iterator iterator = employee.iterator(); iterator.hasNext();) 
			{ 
				Employee employee1 = (Employee) iterator.next(); 
				System.out.println(employee1.getEname()+"  "+
						employee1.getEmployeeAddress().getState());//To get Employee's Name and State 
			}           
			transaction.commit(); 

		} catch (HibernateException e) { 

			transaction.rollback(); 

			e.printStackTrace(); 

		} finally { 

			session.close(); 
		} 
	}


	
}


