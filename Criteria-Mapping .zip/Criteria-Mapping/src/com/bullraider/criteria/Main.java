package com.bullraider.criteria;



import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Expression;

import com.bullraider.criteria.util.HibernateUtil;

public class Main {
	public static void main(String[] args) {
		Main m1=new Main();
		m1.saveEmployee("Rex", "MGR", 30000, 40);
		m1.saveEmployee("Raj", "CLERK", 1000, 30);
		m1.saveEmployee("Mike", "SALESMAN", 8000, 10);
		m1.saveEmployee("Reheman", "MGR", 30000, 10);
		m1.saveEmployee("Raja", "CLERK", 10000, 30);
		m1.saveEmployee("Mittu", "SALESMAN", 8000, 20);
		m1.saveEmployee("Srinivas", "CLERK", 10000, 30);
		m1.saveEmployee("Amit", "SALESMAN", 8000, 20);
		m1.retriveEmployee();

	}
	public Long saveEmployee(String ename,String job,int sal,int deptno)
	{
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		Long empId = null;
		try {
			transaction = session.beginTransaction();
			Employee emp=new Employee();
			emp.setEname(ename);
			emp.setJob(job);
			emp.setSal(sal);
			emp.setDeptno(deptno);
			session.persist(emp);
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return empId;
	}

	public void retriveEmployee() 

	{ 
		final int MINSAL=1000;
		final int MAXSAL=3000;
		Session session = HibernateUtil.getSessionFactory().openSession(); 
		Transaction transaction = null; 
		try { 
			transaction = session.beginTransaction(); 
			Criteria criteria = 
				session.createCriteria(Employee.class).setMaxResults(4);

			List employee= criteria.list(); 
			for (Iterator iterator = employee.iterator(); iterator.hasNext();) 
			{ 
				Employee employee1 = (Employee) iterator.next(); 
				System.out.println(employee1.getEmpno()+"  "+employee1.getEname()+"  "+
						employee1.getJob()+"   "+employee1.getSal()+"   "+employee1.getDeptno()); 
			}           
			transaction.commit(); 

		} catch (HibernateException e) { 

			transaction.rollback(); 

			e.printStackTrace(); 

		} finally { 

			session.close(); 

		} 
	}

} 

