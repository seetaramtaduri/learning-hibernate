package com.bullraider;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.bullraider.util.*;
public class Main {
	public static void main(String[] args) {
		Main main1=new Main();
		main1.saveEmployee("Rex", "MGR", 30000, 10);
		main1.saveEmployee("Raj", "CLERK", 10000, 30);
		main1.saveEmployee("Mike", "SALESMAN", 8000, 10);
	}
	public Long saveEmployee(String ename,String job,int sal,int deptno)
	{
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		Long empId = null;
		try {
			transaction = session.beginTransaction();
			Employee emp=new Employee();
			emp.setEname(ename);
			emp.setJob(job);
			emp.setSal(sal);
			emp.setDeptno(deptno);
			session.save(emp);
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return empId;
	}
} 

