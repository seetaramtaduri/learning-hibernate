package com.bullraider.nsq;


import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
public class EmployeeDao {

	public static void main(String[] args) {
		EmployeeDao dao=new EmployeeDao();
		dao.saveEmployee();
		dao.retriveEmployee();

	}
	public void saveEmployee()

	{

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		Long empId = null;
		try {
			transaction = session.beginTransaction();
			Employee emp1=new Employee("Alok","SALESMAN",20000,10);
			Employee emp2=new Employee("Bibhu","MGR",2000,20);
			Employee emp3=new Employee("Ameet","MGR",18000,10);
			Employee emp4=new Employee("Prasdeep","CLERK",13000,30);
			Employee emp5=new Employee("SUJATA","CLERK",16000,40);
			Employee emp6=new Employee("ALOK","SALESMAN",10000,40);
			Employee emp7=new Employee("LAKSHMI","MGR",11000,30);
			session.save(emp1);
			session.save(emp2);
			session.save(emp3);
			session.save(emp4);
			session.save(emp5);
			session.save(emp6);
			session.save(emp7);
			EmployeeDao dao=new EmployeeDao();
			dao.retriveEmployee();
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}


	}
	public void retriveEmployee() 

	{ 

		Session session = HibernateUtil.getSessionFactory().openSession(); 
		Transaction transaction = null; 
		try { 
			transaction = session.beginTransaction(); 
			System.out.println("HI");
			List emp= session.createQuery(" from Employee where ename like('A%') and job='MGR'").list(); 
			System.out.println("Size is"+" "+emp.size());
			System.out.println("HI");
			for (Iterator iterator = emp.iterator(); iterator.hasNext();) 
			{ 
				Employee employee1 = (Employee) iterator.next(); 
				System.out.println(employee1.getEname()+"  "+
						employee1.getSal()); 
			}           
			transaction.commit(); 

		} catch (HibernateException e) { 

			transaction.rollback(); 

			e.printStackTrace(); 

		} finally { 

			session.close(); 
		} 
	}


}


