package com.bullraider.criteria;


import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Expression;

public class LogicalExpressionInCriteria {
	public static void main(String[] args) {
		LogicalExpressionInCriteria dao=new LogicalExpressionInCriteria();
		dao.saveEmployee("Rex", "MGR", 30000, 40);
		dao.saveEmployee("Raj", "CLERK", 1000, 30);
		dao.saveEmployee("Mike", "SALESMAN", 8000, 10);
		dao.saveEmployee("Mita", null, 30000, 10);
		dao.saveEmployee("Raja", "CLERK", 10000, 30);
		dao.saveEmployee("Mittu", "SALESMAN", 10000, 20);
		dao.saveEmployee("Srinivas", "CLERK", 10000, 30);
		dao.saveEmployee("Amit", "SALESMAN", 8000, 20);
		dao.retriveEmployee();

	}
	public Long saveEmployee(String ename,String job,int sal,int deptno)
	{
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		Long empId = null;
		try {
			transaction = session.beginTransaction();
			Employee emp=new Employee();
			emp.setEname(ename);
			emp.setJob(job);
			emp.setSal(sal);
			emp.setDeptno(deptno);
			session.persist(emp);
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return empId;
	}

	public void retriveEmployee() 

	{ 
		final int MINSAL=10000;
		final int MAXSAL=30000;
		Session session = HibernateUtil.getSessionFactory().openSession(); 
		Transaction transaction = null; 
		try { 
			transaction = session.beginTransaction(); 

			Criteria criteria = 
				session.createCriteria(Employee.class).add(
						Expression.like("ename", "Mit%")).add(
								Expression.between("sal", MINSAL,MAXSAL)).add(
										Expression.and(
												Expression.eq( "deptno", 20 ),
												Expression.isNotNull("job")
										) );	





			List employee= criteria.list(); 
			System.out.println("HI");
			for (Iterator iterator = employee.iterator(); iterator.hasNext();) 
			{ 
				Employee employee1 = (Employee) iterator.next(); 
				System.out.println(employee1.getEmpno()+"  "+employee1.getEname()+"  "+
						employee1.getJob()+"   "+employee1.getSal()+"   "+employee1.getDeptno()); 
			}           
			transaction.commit(); 

		} catch (HibernateException e) { 

			transaction.rollback(); 

			e.printStackTrace(); 

		} finally { 

			session.close(); 

		} 
	}

}
