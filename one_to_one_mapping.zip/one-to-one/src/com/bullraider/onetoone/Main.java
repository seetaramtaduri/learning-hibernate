package com.bullraider.onetoone;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.bullraider.onetoone.util.HibernateUtil;
public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Employee employee=new Employee("Pradeep","SALESMAN",12000,10);
		
			Address address=new Address("Bangalore","Karnattaka","a001","560044","H001");
			employee.setEmployeeAddress(address);
			session.save(employee);
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}


}


