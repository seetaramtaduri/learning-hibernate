package com.bullraider.onetoone;
import java.io.Serializable;

import java.io.Serializable;
public class Employee implements Serializable{
	private long empid;
		private String ename;
	private int sal;
	private String job;
	private int deptno ;
	private Address employeeAddress;
	public Employee( String ename, String job, int sal,int deptno) {
				this.deptno = deptno;
		this.ename = ename;
		this.job = job;
		this.sal = sal;
	}
	public long getEmpid() {
		return empid;
	}

	public void setEmpid(long empid) {
		this.empid = empid;
	}

	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	
	public Address getEmployeeAddress() {
		return employeeAddress;
	}

	public void setEmployeeAddress(Address employeeAddress) {
		this.employeeAddress = employeeAddress;
	}

}
