package com;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.util.*;
public class Main {
	public static void main(String[] args) {
		Main dao=new Main();
		dao.saveEmployee("Rex", "MGR", 30000, 10);
		dao.saveEmployee("Raj", "CLERK", 10000, 30);
		dao.saveEmployee("Mike", "SALESMAN", 8000, 10);
		dao.updateEmployee();
	}
	public Long saveEmployee(String ename,String job,int sal,int deptno)
	{
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		Long empId = null;
		try {
			transaction = session.beginTransaction();
			Employee emp=new Employee();
			emp.setEname(ename);
			emp.setJob(job);
			emp.setSal(sal);
			emp.setDeptno(deptno);
			session.save(emp);
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return empId;
	}


	public  void  updateEmployee() 
	{

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try { 
			transaction = session.beginTransaction();
			String queryString = "from Employee where sal = :sal";
			Connection con = session.connection();  
			CallableStatement cs = con.prepareCall("{ call employeeHike(?) }");
			cs.setInt(1,10000);
			cs.execute();
			System.out.println("Hike has given to employees");
		} catch (HibernateException e) { 

			transaction .rollback(); 

			e.printStackTrace(); 

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finally { 

			session.close(); 

		} 
	}
} 

