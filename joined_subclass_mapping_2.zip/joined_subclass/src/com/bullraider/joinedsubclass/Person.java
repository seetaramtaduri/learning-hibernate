package com.bullraider.joinedsubclass;
import java.io.Serializable;
public class Person implements Serializable{

	protected static int sal;
	private String job;
	private long id;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Person(String job, int sal) {
		super();

		this.job = job;
		this.sal = sal;
	}

	public int getSal() {
		return sal;
	}

	public void setSal(int sal) {
		this.sal = sal;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}



}
