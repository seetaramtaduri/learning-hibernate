package com.bullraider.joinedsubclass;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.bullraider.joinedsubclass.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		Long empId = null;
		try {
			transaction = session.beginTransaction();
			PersonDetails psd1=new PersonDetails("MANAGER",30000,"Susanta","Kundu");
			PersonDetails psd2=new PersonDetails("CLERK",20000,"Amar","Dutta");
			session.save(psd1);
			session.save(psd2);
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}


}



