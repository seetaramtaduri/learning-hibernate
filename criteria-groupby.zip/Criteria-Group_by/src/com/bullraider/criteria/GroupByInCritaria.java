package com.bullraider.criteria;



import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;

public class GroupByInCritaria {
	public static void main(String[] args) {
		GroupByInCritaria dao=new GroupByInCritaria();
		dao.saveEmployee("Rex", "MGR", 30000, 40);
		dao.saveEmployee("Raj", "CLERK", 1000, 30);
		dao.saveEmployee("Mike", "SALESMAN", 8000, 10);
		dao.saveEmployee("Reheman", "MGR", 30000, 10);
		dao.saveEmployee("Raja", "CLERK", 10000, 30);
		dao.saveEmployee("Mittu", "SALESMAN", 8000, 20);
		dao.saveEmployee("Srinivas", "CLERK", 10000, 30);
		dao.saveEmployee("Amit", "SALESMAN", 8000, 20);
		dao.retriveEmployee();

	}
	public Long saveEmployee(String ename,String job,int sal,int deptno)
	{
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		Long empId = null;
		try {
			transaction = session.beginTransaction();
			Employee emp=new Employee();
			emp.setEname(ename);
			emp.setJob(job);
			emp.setSal(sal);
			emp.setDeptno(deptno);
			session.persist(emp);
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return empId;
	}

	@SuppressWarnings("unchecked")
	public void retriveEmployee() 

	{ 
		final int MINSAL=1000;
		final int MAXSAL=3000;
		Session session = HibernateUtil.getSessionFactory().openSession(); 
		Transaction transaction = null; 
		try { 
			transaction = session.beginTransaction(); 
			System.out.println("HI");
			List employee = 
				session.createCriteria(Employee.class).setProjection( 
						Projections.projectionList().add( 
								Projections.max("sal") ).add (Projections.property("deptno") ).
								add( 
										Projections.groupProperty("deptno"))).list();

			List results = session.createCriteria(Employee.class)
			.setProjection( Projections.projectionList().add( 
					Projections.avg("sal"), "avgsal" )
					.add( Projections.max("sal"), "maxsal" )
					.add( Projections.groupProperty("deptno"), "deptno" )
			)
			
			.addOrder( Order.desc("avgsal") )
			.list();
			System.out.println("HI");
			for (Iterator iterator = employee.iterator(); iterator.hasNext();) 
			{ 
				Employee employee1 = (Employee) iterator.next(); 
				System.out.println(employee1.getEmpno()+"  "+employee1.getEname()+"  "+
						employee1.getJob()+"   "+employee1.getSal()+"   "+employee1.getDeptno()); 
			}           
			transaction.commit(); 

		} catch (HibernateException e) { 

			transaction.rollback(); 

			e.printStackTrace(); 

		} finally { 

			session.close(); 

		} 
	}

}
