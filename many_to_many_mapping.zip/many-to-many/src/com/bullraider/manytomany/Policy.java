package com.bullraider.manytomany;
public class Policy {
	private long policyId;
	private String policyName;
		public long getPolicyId() {
		return policyId;
		
	}
	public void setPolicyId(long policyId) {
		this.policyId = policyId;
	}

	public Policy( String policyName) {
		super();
		this.policyName = policyName;
	}
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

}
