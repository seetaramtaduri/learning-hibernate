package com.bullraider.manytomany;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


import com.bullraider.manytomany.util.HibernateUtil;

public class Main {


	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Set<Policy> policySet = new HashSet<Policy>();
			policySet.add(new Policy("JeevanSalal"));
			policySet.add(new Policy("Retirementplan"));
			Customer c1=new Customer("Abbi");
			c1.setPolicyies(policySet);
			Customer c2=new Customer("Mita");
			c2.setPolicyies(policySet);
			session.save(c1);
			session.save(c2);
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

}
