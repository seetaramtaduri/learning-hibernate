package com.bullraider.manytomany;
import java.util.HashSet;
import java.util.Set;
public class Customer {
	private String name;
	private long custmerId;
	private Set<Policy> policyies = new HashSet<Policy>(0);
	public Set<Policy> getPolicyies() {
		return policyies;
	}

	public void setPolicyies(Set<Policy> policyies) {
		this.policyies = policyies;
	}

	public Customer(String name) {

		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getCustmerId() {
		return custmerId;
	}

	public void setCustmerId(long custmerId) {
		this.custmerId = custmerId;
	}


}
