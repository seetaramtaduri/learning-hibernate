package com.bullraider.cmpositekey;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.bullraider.cmpositekey.util.HibernateUtil;

public class Main {
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Account account1=new Account("H1001","MG ROAD","NEELESH",23330,"savings");
			Account account2=new Account("H1004","MG ROAD","NIRLIPTA",23330,"savings");
			session.save(account1);
			session.save(account2);
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}
}
