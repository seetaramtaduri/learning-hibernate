package com.bullraider.cmpositekey;
import java.io.Serializable;
public class Account implements Serializable{
	private String place;
	private String  houseno;
	private String accounId;
	private String name;
	private String type;
	private int amount;
	public Account( String houseno,String place, String name,int amount, 
			String type) {
		this.amount = amount;
		this.houseno = houseno;
		this.name = name;
		this.place = place;
		this.type = type;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getHouseno() {
		return houseno;
	}
	public void setHouseno(String houseno) {
		this.houseno = houseno;
	}
	public String getAccounId() {
		return accounId;
	}
	public void setAccounId(String accounId) {
		this.accounId = accounId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	@Override
	public boolean equals(Object obj){
		if(obj instanceof Account){
			Account acc=(Account)obj;
			if(this.name.equals(acc.getPlace()) &&
					this.houseno==acc.getHouseno())
				return true;
			else
				return false;
			}
		else{
			return false;
		}
	}
	
	
	public int hashCode() {
	int hc;
	hc = place.hashCode();
	hc = 5* hc+ houseno.hashCode();
	return hc;
	}

}
