package com.bullraider.onetomany;
import java.util.HashSet;
import java.util.Set;
public class Faculty {
	private long id;
	private String name;
		private Set<Subject> subjects=new HashSet<Subject>(0);
		public Faculty(String name) {
		super();
		this.name = name;
		
	}
	public Set<Subject> getSubjects() {
		return subjects;
	}
	public void setSubjects(Set<Subject> subjects) {
		this.subjects = subjects;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
