package com.bullraider.onetomany;
import java.util.HashSet;
import java.util.Set;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.bullraider.onetomany.util.HibernateUtil;
public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Set<Subject> subject= new HashSet<Subject>();

			subject.add(new Subject("Java"));
			subject.add(new Subject("C++"));
			Faculty fc1=new Faculty("Srinivas");
			fc1.setSubjects(subject);
			session.save(fc1);
			transaction.commit();
			System.out.println("Records inserted sucessessfully");
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}


}