package com.bullraider.componentmapping.persondetails;

import com.bullraider.componentmapping.person.Person;

public class PersonDetails extends Person{
public PersonDetails(String job, int sal,String fname,String lname) {
	
		super(job, sal);
		this.fname=fname;
		this.lname=lname;
	}
private String fname;
private String lname;

public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
}
