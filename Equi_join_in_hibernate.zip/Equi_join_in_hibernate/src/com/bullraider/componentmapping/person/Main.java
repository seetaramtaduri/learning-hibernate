package com.bullraider.componentmapping.person;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.bullraider.componentmapping.persondetails.PersonDetails;
import com.bullraider.componentmapping.util.HibernateUtil;


public class Main {

	public static void main(String[] args) {
		Main m=new Main();
		m.createPerson();
		m.retrivePerson();
		

	}
	public void createPerson()
	{
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		Long empId = null;
		try {
			transaction = session.beginTransaction();
						PersonDetails psd=new PersonDetails("MANAGER",30000,"Susanta","Kundu");
			session.save(psd);
						System.out.println("Records inserted sucessessfully");
						Main m=new Main();
						m.retrivePerson();
						
						transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		
	}
	public void retrivePerson() 

	{ 

		Session session = HibernateUtil.getSessionFactory().openSession(); 
		Transaction transaction = null; 
		try { 
			transaction = session.beginTransaction(); 
			System.out.println("HI");
			List emp= session.createQuery(" select PersonDetails.id,sal from Person,PersonDetails").list(); 
			System.out.println("Size is"+" "+emp.size());
			System.out.println("HI");
			for (Iterator iterator = emp.iterator(); iterator.hasNext();) 
			{ 
				PersonDetails  p = (PersonDetails) iterator.next(); 
				System.out.println(p.getId()+"  "+
						p.getSal()); 
			}           
			transaction.commit(); 

		} catch (HibernateException e) { 

			transaction.rollback(); 

			e.printStackTrace(); 

		} finally { 

			session.close(); 
		} 
	}



}



